#!/usr/bin/env bash
# Usage: bash push_to_github.sh YOUR-USERNAME
set -e
USER="${1:?Provide your GitHub username}"
python train_model.py            # creates student_data.csv and student_model.pkl
git init
git add train_model.py app.py requirements.txt README.md .gitignore student_data.csv student_model.pkl
git commit -m "Build student performance prediction prototype"
git branch -M main
git remote add origin "https://github.com/$USER/student-performance-prediction.git"
git push -u origin main
